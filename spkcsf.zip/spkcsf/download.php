<?php
if(isset($_GET['filename']))
{

$filename=$_GET['filename'].".xls";
header("Content-Disposition:attachment;filename=\"$filename\"");
header("Content-Type:application/vnd.ms-excel");
include 'db.php';
$sql = "select * from personal join academic_details on personal.rollno=academic_details.rollno join parent_details on personal.rollno=parent_details.rollno where personal.rollno='$search'";

//$sql="";
$result=$conn->query($sql);

//if(mysqli_num_rows($result)>0)
if($result)
{
	$heading=false;
	while($row=mysqli_fetch_assoc($result)){
	if(!$heading){
		echo implode("\t",array_keys($row))."\r\n";
		$heading=true;
	}
	echo implode("\t",array_values($row))."\r\n";
	}
}
}