<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="retrieval.css">
    <title>Admin</title>

</head>

<body>
    <div class="header">

        <div class="logo">
            <img src="spkclogo.png" alt="" height="100px" width="100px" style="border-radius: 0px;">
            <div class="clg-name" style="margin-left:10px;">
                <h1 style="color:#ffffff"><span style="font-size:38px;">S</span>ri <span style="font-size:38px;">P</span>aramkalyani <span style="font-size:38px;">C</span>ollege</h1>
                <h2 style="color:rgb(255, 255, 255); font-size:20px; text-align:center;">Alwarkurichi, Tenkasi District
                </h2>
            </div>
        </div>
        <div class="menus">
            <ul>
                <a href="index.html">
                    <li>Home </li>
                </a>
                <a href="update.php">
                    <li>Update </li>
                </a>
                <a href="retrieval.php">
                    <li>Retrieve </li>
                </a>
                <a href="sampleretrieve.php">
                    <li>update </li>
                </a>
            </ul>
        </div>

    </div>
    <form action="" method="POST">
        <section id="Applicant_Personal">
            <h1 style="margin-left: 15px;">GET DETAILS</h1>
            <div class="personal">
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="c_name">Course Name<span class="mandatory">*</span>
                        </label>
                        <select id='crs_name' name='course_name' placeholder="Select Year" required>
                            <option value="">Select</option>
                            <option value="B.A.-English">B.A.English</option>
                            <option value="B.Com">B.Com</option>
                            <option value="B.Com(CS)">B.Com(CS)</option>
                            <option value="BCA I-Batch">BCA I-Batch</option>
                            <option value="BCA II-Batch">BCA II-Batch</option>
                            <option value="B.Sc.Maths">B.Sc.Maths</option>
                            <option value="B.Sc.Bio Tech">B.Sc.Bio Tech</option>
                            <option value="B.Sc.E&C">B.Sc.E&C</option>
                            <option value="B.Sc.Computer Science">B.Sc.Computer Science</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="a_year">Academic Year
                        </label>
                        <input type="text" id="a_year" name="a_year" placeholder="Enter Academic Year(Ex:2021-2022)"/>

                    </div>
                    <div class="frm-template">
                        <label for="clsyear">Year
                        </label>
                        <select id='year' name='year' placeholder="Select Year">
                            <option value="">Select</option>
                            <option value="I Year">I Year</option>
                            <option value="II Year">II Year</option>
                            <option value="III Year">III Year</option>
                        </select>
                    </div>

                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="nation">Community
                        </label>
                        <select name="community" id="community">
                            <option value="" selected>Select</option>
                            <option value="BC">BC</option>
                            <option value="BCM">BCM</option>
                            <option value="DNC">DNC</option>
                            <option value="MBC">MBC</option>
                            <option value="OC">OC</option>
                            <option value="SC">SC</option>
                            <option value="SCA">SCA</option>
                            <option value="ST">ST</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="schltype">School Type
                        </label>
                        <select name="schltype" id="schltype">
                            <option value="" selected>Select</option>
                            <option value="Goverment">Goverment</option>
                            <option value="Govt.Aided">Govt.Aided</option>
                            <option value="Private">Private</option>
                            <option value="CBSE">CBSE</option>
                        </select>
                    </div>


                    <div class="frm-template">
                        <label for="first_graduation">First Graduation
                        </label>
                        <select name="first_graduation">
                            <option value="" selected>Select</option>
                            <option value="YES">Yes</option>
                            <option value="NO">No</option>
                        </select>
                    </div>
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="con-no">Father Occupation
                        </label>
                        <select name="foccupation" id="con-no">
                            <option value="">select</option>
                            <option value="Dailywages">DailyWages</option>
                            <option value="Farmer">Farmer</option>
                            <option value="Goverment">Goverment</option>
                            <option value="Private">Private</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="con-no1">Mother Occupation
                        </label>
                        <select name="moccupation" id="con-no1">
                            <option value="">select</option>
                            <option value="Homemaker">Homemaker</option>
                            <option value="BeediWorker">Beedi Worker</option>
                            <option value="Dailywages">DailyWages</option>
                            <option value="Goverment">Goverment</option>
                            <option value="Private">Private</option>

                        </select>
                    </div>
                    <div class="frm-template">
                    </div>

                </div>

                <button class="btn" id="retrievebtn" value="search" name="Retrieve" style="position: relative;right:-80% !important;">search</button>
                <a href="download.php?filename=spkc"><button class="btn" id="retrievebtn" value="search" name="Retrieve" style="position: relative;right:-80% !important;">XL SHEET</button></a>

            </div>

    </form>
    </section>
    <section>
        <!--div class="dbresult"-->
        <table class="table table-order">
            <!--div class="dbresult th"-->

            <tr>
                <th>Rollno </th>
                <th>Student Name</th>
                <th>Email</th>
                <th>Phone no</th>
                <th>Class</th>
            </tr>

            <?php
            if (isset($_POST['Retrieve'])) {

                $course_name = $_POST['course_name'];
				$a_year=$_POST['a_year'];
                $year = $_POST['year'];
				$community=$_POST['community'];
                $schltype = $_POST['schltype'];
                $first_graduation = $_POST['first_graduation'];
                $foccupation = $_POST['foccupation'];
                $moccupation = $_POST['moccupation'];
                $sql = "
			SELECT *
            FROM personal
            JOIN academic_details ON personal.rollno = academic_details.rollno
            JOIN parent_details ON personal.rollno = parent_details.rollno
            WHERE academic_details.course_name = '$course_name'";

                //academic_details.course_type = ?

                if (!empty($a_year)) {
                    $sql .= " AND academic_details.academic_year='$a_year'";
                }
				if (!empty($year)) {
                    $sql .= " AND academic_details.year='$year'";
                }
				if (!empty($community)) {
                    $sql .= " AND personal.community='$community'";
                }
                if (!empty($schltype)) {
                    $sql .= " AND personal.schltype='$schltype'";
                }
                if (!empty($first_graduation)) {
                    $sql .= " AND personal.first_graduation='$first_graduation'";
                }
                if (!empty($foccupation)) {
                    $sql .= " AND parent_details.f_occupation='$foccupation'";
                }
                if (!empty($moccupation)) {
                    $sql .= " AND parent_details.m_occupation='$moccupation'";
                }


                $result = mysqli_query($conn, $sql);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
			<tr>
			<td>' . $row['rollno'] . '</td>
			<td>' . $row['sname'] . '</td>
			<td>' . $row['email'] . '</td>
			<td>' . $row['phno'] . '</td>
			<td>' . $row['course_name'] . '</td>
			
			</tr>';
                }
            }
            ?>
            </div>
        </table>
    </section>
</body>

</html>