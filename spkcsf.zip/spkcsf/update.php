<?php
include 'db.php';
if (isset($_POST['Update'])) {

    $search = $_POST['rollno'];

    $sname = $_POST['sname'];
    $s_dob = $_POST['s_dob'];
    $gender = $_POST['gender'];
    $phno = $_POST['phno'];
    $wtsapp = $_POST['wtsapp'];
    $email = $_POST['email'];
    $schltype = $_POST['schltype'];
    $schlstu = $_POST['schlstu'];
    $emis = $_POST['emis'];
    $religion = $_POST['religion'];
    $community = $_POST['community'];
    $caste = $_POST['caste'];
    $nation = $_POST['nation'];
    $mother_tongue = $_POST['mother_tongue'];
    $aadharno = $_POST['aadharno'];
    $first_graduation = $_POST['first_graduation'];

    $rollno = $_POST['rollno'];
    $regno = $_POST['regno'];
    $a_year = $_POST['a_year'];
    $a_no = $_POST['a_no'];
    $admdate = $_POST['admdate'];
    $c_type = $_POST['c_type'];
    $c_name = $_POST['c_name'];
    $year = $_POST['year'];
    $tcno = $_POST['tcno'];
    $tcappdate = $_POST['tcappdate'];
    $tc_issue_date = $_POST['tc_issue_date'];
    $remarks = $_POST['remarks'];

    $relation = $_POST['relation'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $gname = $_POST['gname'];
    $foccupation = $_POST['foccupation'];
    $moccupation = $_POST['moccupation'];
    $goccupation = $_POST['goccupation'];
    $gann_income = $_POST['gann_income'];
    $ann_income = $_POST['ann_income'];
    $parent_contact = $_POST['parent_contact'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $district = $_POST['district'];
    $state = $_POST['state'];
    $pin_code = $_POST['pin_code'];

    $query1 = "update personal set sname='$sname',s_dob='$s_dob',gender='$gender',phno='$phno',wtsapp='$wtsapp',email='$email',schltype='$schltype',schlstu='$schlstu',emis='$emis',religion='$religion',community='$community',caste='$caste',nation='$nation',mother_tongue='$mother_tongue',aadharno='$aadharno',first_graduation='$first_graduation' where rollno='$search'";
    $query2 = "update academic_details set rollno='$rollno',regno='$regno',academic_year='$a_year',adm_num='$a_no',adm_date='$admdate',course_type='$c_type' course_name='$c_name',year='$year',tc_no='$tcno',tc_application_date='$tcappdate',tc_issue_date='$tc_issue_date',remarks='$remarks' where rollno='$search'";
    $query3 = "update parent_details set relation='$relation',fname='$fname',mname='$mname',gname='$gname',f_occupation='$foccupation',m_occupation='$moccupation' goccupation='$goccupation',gann_income='$gann_income',ann_income='$ann_income',parent_contact='$parent_contact',address='$address',city='$city',district='$district',state='$state',pin_code='$pin_code' where rollno='$search'";

    mysqli_query($conn,$query1);
    mysqli_query($conn,$query2);
    mysqli_query($conn,$query3);
    
    echo "<script type='text/javascript'>alert('successfully updated')</script>";
} 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="update.css">
    <script src=script.js> </script>
    <title>Admin</title>

</head>

<body>
    <div class="header">

        <div class="logo">
            <img src="spkclogo.png" alt="" height="100px" width="100px" style="border-radius: 0px;">
            <div class="clg-name" style="margin-left:10px;">
                <h1 style="color:#ffffff"><span style="font-size:38px;">S</span>ri <span style="font-size:38px;">P</span>aramkalyani <span style="font-size:38px;">C</span>ollege</h1>
                <h2 style="color:rgb(255, 255, 255); font-size:20px; text-align:center;">Alwarkurichi, Tenkasi District
                </h2>
            </div>
        </div>
        <div class="menus">
            <ul>
                <a href="index.html">
                    <li>Home </li>
                </a>
                <a href="update.php">
                    <li>Update </li>
                </a>

                <a href="retrieval.php">
                    <li>Retrieve </li>
                </a>
                <a href="sampleretrieve.php">
                    <li>update </li>
                </a>
            </ul>
        </div>

    </div>
    <form action="" method="POST">
        <div class="update">
            <div id="update-field">
                <h2 style="text-align:center;">Search Roll Number</h2>
                <input type="text" placeholder=" Rollno(Ex-21646)" name="search" id="search">
                <button id="updatebtn" value="search" name="submit">search</button>
            </div>
        </div>
    </form>
    <?php
    if (isset($_POST['submit'])) {
        $search = $_POST['search'];
        $sql = "select * from personal join academic_details on personal.rollno=academic_details.rollno join parent_details on personal.rollno=parent_details.rollno where personal.rollno='$search'";
        //$sql="select *from personal where rollno='$search'";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            echo ' 
    <section id="Applicant_Personal">
        <h1 style="margin-left: 15px;">Student Details</h1>
		<form  action="" method="POST">
        <div class="personal">
            <h2>Personal Details</h2>
	   
			<div class="personal_row_1">
                    <div class="frm-template">
                        <label for="sname">Student Name
                        </label>
                        <input type="text" id="sname" name="sname" value=' . $row["sname"] . ' placeholder="Enter StudentName"   />
                    </div>
                    <div class="frm-template">
                        <label for="s_dof">Date of Birth
                        </label>
                        <input type="date" name="s_dob" value=' . $row["s_dob"] . ' id="s_dof" placeholder="Enter Date of Birth"    />
                    </div>
                    <div class="frm-template">
                        <label for="Gender">Gender
                        </label>
                        <select name="gender" id="Gender"  >
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <label class="info">Current Value:'. $row["gender"] .'</lable>

                    </div>

                </div>

                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="phone">Phone Number
                        </label>
                        <input type="text" id="phone" maxlength="10" name="phno" value=' . $row["phno"] . ' placeholder="Enter PhoneNumber"  />
                    </div>

                    <div class="frm-template">

                        <label for="wtsapp">Whatsapp Number
                        </label>
                        <input type="text" id="wtsapp" maxlength="10" minlength="10" name="wtsapp" value=' . $row["wtsapp"] . ' placeholder="Enter WhatsappNumber"    />
                    </div>
                    <div class="frm-template">
                        <label for="state">Mail Id<span class="mandatory">*</span>
                        </label>
                        <input type="email" id="mailid" name="email" value=' . $row["email"] . ' placeholder="Enter Mail-Id"    />
                    </div>

                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="schltype">School Type
                        </label>
                        <select name="schltype" id="schltype"   >
                            <option value="Goverment">Goverment</option>
                            <option value="Govt.Aided">Govt.Aided</option>
                            <option value="Private">Private</option>
                            <option value="CBSE">CBSE</option>
                        </select>
                        <label class="info">Current Value:'. $row["schltype"] .'</lable>
                    </div>

                    <div class="frm-template">
                        <label for="sclname">School Name
                        </label>
                        <input type="text" id="sclname" name="schlstu" value=' . $row["schlstu"] . ' placeholder="School Name"    />
                    </div>
                    <div class="frm-template">
                        <label for="emis">Emis Number
                        </label>
                        <input type="text" name="emis" id="emis" value=' . $row["emis"] . ' placeholder="Enter EmisNumber"    />
                    </div>
                </div>


                <div class="personal_row_1">


                    <div class="frm-template">
                        <label for="nation">Religion
                        </label>
                        <select name="religion"   
                        >
                        <option value="">Select</option>   
                        <option value="Hindu">Hindu</option>
                        <option value="Chirstian">Chirstian</option>
                        <option value="Muslim">Muslim</option>
                        </select>
                        <label class="info">Current Value:'. $row["religion"] .'</lable>
                    </div>
                    <div class="frm-template">
                        <label for="nation">Community
                        </label>
                        <select name="community" id="community" onchange="CasteRender();"   >
                        </select>
                        <label class="info">Current Value:'. $row["community"] .'</lable>
                    </div>
                    <div class="frm-template">

                        <label for="nation">Caste
                        </label>
                        <select name="caste" id="comm_caste"  required  >
                        </select>
                        <label class="info">Current Value:'. $row["caste"] .'</lable>
                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="nation">Nationality
                        </label>
                        <select name="nation"  >
                            <option value="" selected>Select</option>
                            <option value="Indian">Indian</option>
                            <option value="Others">Others</option>
                        </select>
                        <label class="info">Current Value:'. $row["nation"] .'</lable>
                    </div>

                    <div class="frm-template">

                        <label for="nation">Mother Tongue
                        </label>
                        <select name="mother_tongue"  >
                            <option value="" selected>Select</option>
                            <option value="Tamil">Tamil</option>
                            <option value="Malayalam">Malayalam</option>
                            <option value="Telugu">Telugu</option>
                            <option value="Kannada">Kannda</option>
                            <option value="Hindi">Hindi</option>
                            <option value="Others">Others</option>
                        </select>
                        <label class="info">Current Value:'. $row["mother_tongue"] .'</lable>
                    </div>
                    <div class="frm-template">
                        <label for="aadharno">Aadhar Number
                        </label>
                        <input type="text" name="aadharno" value=' . $row["aadharno"] . ' maxlength="12" id="aadharno" placeholder="Enter AadharNumber"    />
                    </div>
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="first_graduation">First Graduation
                        </label>
                        <select name="first_graduation"  >
                            <option value="" selected>Select</option>
                            <option value="YES">Yes</option>
                            <option value="NO">No</option>
                        </select>
                        <label class="info">Current Value:'. $row["first_graduation"] .'</lable>
                    </div>
                </div>
				<div></div>
				<div></div>
	
                <a href="#Applicant_Academic"><input type="button" class="btn " value="Next"
                        style="position: relative;right:-80% !important;"></a>
	


        </div>
		</section>
		
		<section id="Applicant_Academic">
        <div class="Academic_Details">
            <h2>Academic Details</h2>


                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="rollno">Roll Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="rollno" name="rollno" value=' . $row["rollno"] . ' placeholder="Enter RollNumber"    />
                    </div>
                    <div class="frm-template">
                        <label for="regno">Register Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="regno" id="regno" value=' . $row["regno"] . ' placeholder="Enter RegisterNumber"    />
                    </div>
                   
                    <div class="frm-template">
                        <label for="a_year">Academic Year<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="a_year" name="a_year" value=' . $row["academic_year"] . ' placeholder="Enter Academic Year(Ex:2021-2022)"    />

                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="admno">Admission Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="admno" name="a_no" value=' . $row["adm_num"] . ' placeholder="Enter AdmissionNumber"    />
                    </div>
                    <div class="frm-template">
                        <label for="admdate">Admission Date
                        </label>
                        <input type="date" name="admdate" value=' . $row["adm_date"] . ' id="admdate" placeholder="Enter AdmissionDate" />
                    </div>
					<div class="frm-template">
                    <label for="C_type">CourseType<span class="mandatory">*</span>
                    </label>
                    <select name="c_type" id="C_type" onchange="course_show()"  >
						<option value="">Select</option>
                        <option value="ug">UG</option>
                        <option value="pg">PG</option>
                    </select>
                    <label class="info">Current Value:'. $row["course_type"] .'</lable>
                    
                </div>
                    
                    
                </div>
                <div class="personal_row_1">
                    
                <div class="frm-template">
                <label for="c_name">Course Name<span class="mandatory">*</span>
                </label>
                <select name="c_name" id="c_name" required >

                </select>
                <label class="info">Current Value:'. $row["course_name"] .'</lable>
            </div>
					<div class="frm-template">
                        <label for="clsyear">Year<span class="mandatory">*</span>
                        </label>
                        <select name="year" id="clsyear" >
							
                            <option value="">Select</option>
                            <option value="year_1">I Year</option>
                            <option value="year_2">II Year</option>
                            <option value="year_3">III Year</option>
                        </select>
                        <label class="info">Current Value:'. $row["year"] .'</lable>
                    </div>
					<div class="frm-template">

                        <label for="tcno">Tc No
                        </label>
                        <input type="Text" id="tcno" name="tcno" value=' . $row["tc_no"] . ' placeholder="Enter Tc No" />
                    </div>
                    
                    
                  
                </div>
                
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="tcappdate">TC Application Date
                        </label>
                        <input type="date" id="tcappdate" name="tcappdate"  placeholder="TC Application Date" value=' . $row["tc_application_date"] . '  />
                    </div>
					<div class="frm-template">
                        <label for="tc_issue_date">TC Issue Date
                        </label>
                        <input type="date" id="tc_issue_date" name="tc_issue_date" placeholder="TC Issue Date" value=' . $row["tc_issue_date"] . '  />
                    </div>
                    <div class="frm-template">
					<label for="remarks">Remarks<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="remarks" name="remarks" required placeholder="Enter Any Remarks" value=' . $row["remarks"] . ' >
					
					</div>

                </div>
                <a href="#Applicant_other">
                    <input type="button" class="btn" style="position: relative;right:-80% !important;" value="Next"></a>


   
        </div>

    </section>

    <section id="Applicant_other">

<div class="Academic_Details">
    <h2>Parent/Guardian Details</h2>

    <div class="personal_row_1">

        <div class="frm-template">
            <label for="relation">Select Relation:</label>
            <select id="relation" name="relation" onchange="showInfo()"   >

                <option value="parent">Parent</option>
                <option value="guardian">Guardian</option>
            </select>
            <label class="info">Current Value:'. $row["relation"] .'</lable>
        </div>
        <div class="personal_row_1" id="fatherInfo" >
        <div class="frm-template" style="margin-left:3vw;">
            <label for="fname">Father Name<span class="mandatory">*</span>
            </label>
            <input type="text" name="fname"  id="fname" placeholder="Enter FatherName"  value=' . $row["fname"] . '   />
        </div>

        <div class="frm-template">
            <label for="con-no">Father Occupation<span class="mandatory">*</span>
            </label>
            <select name="foccupation" id="con-no">
            <option value="">select</option>
            <option value="Dailywages">DailyWages</option>
            <option value="Goverment">Goverment</option>
            <option value="Private">Private</option>
        </select>
            <label class="info">Current Value:'. $row['f_occupation'] .'</lable>

        </div>
    </div>
    </div>
    <div class="personal_row_1" id="guardianInfo" style="display:none">
        <div class="frm-template">
            <label for="gname">Guardian Name<span class="mandatory">*</span>
            </label>
            <input type="text" id="gname" placeholder="Enter Guardian name" name="gname" value=' . $row["gname"] . '   />
        </div>
        <div class="frm-template">
            <label for="con-no">Guardian Occupation<span class="mandatory">*</span>
            </label>
            <select name="goccupation" id="con-no">
                <option value="">select</option>
                <option value="Dailywages">DailyWages</option>
                <option value="Goverment">Goverment</option>
                <option value="Private">Private</option>
            </select>
            <label class="info">Current Value:'. $row['goccupation'] .'</lable>
        </div>
        <div class="frm-template">
            <label for="ann-income">Annual Income<span class="mandatory">*</span>
            </label>
            <input type="text" id="ann-income" name="gann_income"  placeholder="Annual Income" value=' . $row["gann_income"] . '   />
        </div>
    </div>
    <div class="personal_row_1" id="Hidden_SelectGuad">
        <div class="frm-template">
            <label for="mname">Mother Name<span class="mandatory">*</span>
            </label>
            <input type="text" id="mname" name="mname" placeholder="Enter MotherName"  value=' . $row["mname"] . '  />
        </div>

        <div class="frm-template">
            <label for="con-no1">Mother Occupation
            </label>
            <select name="moccupation" id="con-no1">
            <option value="">select</option>
            <option value="Homemaker">Homemaker</option>
            <option value="BeediWorker">Beedi Worker</option>
            <option value="Dailywages">DailyWages</option>
            <option value="Goverment">Goverment</option>
            <option value="Private">Private</option>
           
        </select>
            <label class="info">Current Value:'. $row['m_occupation'] .'</lable>
        </div>

        <div class="frm-template">
            <label for="ann-income">Annual Income<span class="mandatory">*</span>
            </label>
            <input type="text" id="ann-income" name="ann_income" value=' . $row["ann_income"] . ' placeholder="Annual Income"  />
        </div>
    </div>

    <div class="personal_row_1">

        <div class="frm-template">
            <label for="con-no">Contact Number<span class="mandatory">*</span>
            </label>
            <input type="text" id="con-no" name="parent_contact"  placeholder="Enter PhoneNumber" value=' . $row["parent_contact"] . '   />
        </div>
        <div class="frm-template">
            <label for="saddress">Street<span class="mandatory">*</span>
            </label>
            <input type="text" id="saddress" name="address" value=' . $row["address"] . ' placeholder="Enter Address"  />
        </div>
        <div class="frm-template">
            <label for="city">Rural/City<span class="mandatory">*</span>
            </label>
            <input type="text" id="city" name="city" value=' . $row["city"] . ' placeholder="Enter CityName"  />
        </div>


    </div>

    <div class="personal_row_1">
        <div class="frm-template">

            <label for="district">District<span class="mandatory">*</span>
            </label>
            <input type="text" id="district" name="district" value=' . $row["district"] . ' placeholder="Enter DistrictName"  />
        </div>
        <div class="frm-template">

            <label for="state">State<span class="mandatory">*</span>
            </label>
            <input type="text" id="state" name="state" value=' . $row["state"] . '  placeholder="Enter StateName"  />
        </div>

        <div class="frm-template">
            <label for="pin-code">Pincode<span class="mandatory">*</span>
            </label>
            <input type="text" id="pin-code" name="pin_code" value=' . $row["pin_code"] . ' placeholder="Enter Pincode"  />
        </div>



    </div>
    <div class="personal_row_1" style="justify-content: flex-start;">


    </div>
    <div class="btn-control">

        <!--input type="button" style="background-color: rgb(31, 224, 10);" class="btn save" value="save"-->
        <!--button type="clear" style="background-color: #ce5353;" id="clr" class="btn clr" value="clear"-->
        <input type="submit" class="btn submit" value="Update" name="Update">

    </div>

</div>

</section>  ';
        }
    }
    ?>
    </form>


</body>

</html>