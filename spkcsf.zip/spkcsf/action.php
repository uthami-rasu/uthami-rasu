<?php
include 'db.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    
    $sname = $_POST['sname'];
    $s_dob = $_POST['s_dob'];
    $gender = $_POST['gender'];
    $phno = $_POST['phno'];
    $wtsapp = $_POST['wtsapp'];
    $email = $_POST['email'];
    $schltype = $_POST['schltype'];
    $schlstu = $_POST['schlstu'];
    $emis = $_POST['emis'];
    $religion = $_POST['religion'];
    $community = $_POST['community'];
    $caste = $_POST['caste'];
    $nation = $_POST['nation'];
    $mother_tongue = $_POST['mother_tongue'];
    $aadharno = $_POST['aadharno'];
    $first_graduation = $_POST['first_graduation'];

    $rollno = $_POST['rollno'];
    $regno = $_POST['regno'];
    $a_year = $_POST['a_year'];
    $admdate = $_POST['admdate'];
    $c_type = $_POST['c_type'];
    $c_name = $_POST['c_name'];
	$year = $_POST['year'];
    $tcno = $_POST['tcno'];
    $tcappdate = $_POST['tcappdate'];
	$tc_issue_date=$_POST['tc_issue_date'];
	$remarks=$_POST['remarks'];
	

	$relation=$_POST['relation'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $gname = $_POST['gname'];
    $foccupation = $_POST['foccupation'];
    $moccupation = $_POST['moccupation'];
    $goccupation=$_POST['goccupation'];
    $gann_income=$_POST['gann_income'];
    $ann_income = $_POST['ann_income'];
    $parent_contact = $_POST['parent_contact'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $district = $_POST['district'];
    $state = $_POST['state'];
    $pin_code = $_POST['pin_code'];
    
    
   if(!empty($rollno) && !empty($sname) && !empty($s_dob) && !empty($gender) && !empty($phno) && !empty($wtsapp) &&!empty($email) && !empty($schltype) &&!empty($schlstu) &&!empty($emis) && !empty($religion) && !empty($community) && !empty($caste) && !empty($nation) && !empty($mother_tongue) && !empty($aadharno) && !empty($first_graduation) && !empty($regno) && !empty($a_year)  && !empty($c_type) && !empty($c_name)   && !empty($parent_contact) && !empty($address) && !empty($city) && !empty($district) &&!empty($state) && !empty($pin_code))
    { 
        $query1 = "insert into personal(rollno,sname,s_dob,gender,phno,wtsapp,email,schltype,schlstu,emis,religion,community,caste,nation,mother_tongue,aadharno,first_graduation)values('$rollno','$sname','$s_dob','$gender','$phno','$wtsapp','$email','$schltype','$schlstu','$emis','$religion','$community','$caste','$nation','$mother_tongue','$aadharno','$first_graduation')";
        $query2 = "insert into academic_details(rollno,regno,academic_year,adm_date,course_type,course_name,year,tc_no,tc_application_date,tc_issue_date,remarks)values('$rollno','$regno','$a_year','$admdate','$c_type','$c_name','$year','$tcno','$tcappdate','$tc_issue_date','$remarks')";
        $query3 = "insert into parent_details(rollno,relation,fname,mname,gname,f_occupation,m_occupation,goccupation,gann_income,ann_income,parent_contact,address,city,district,state,pin_code)values('$rollno','$relation','$fname','$mname','$gname','$foccupation','$moccupation','$goccupation','$gann_income','$ann_income','$parent_contact','$address','$city','$district','$state','$pin_code')";
        mysqli_query($conn,$query1);
        mysqli_query($conn,$query2);
        mysqli_query($conn,$query3);  
		//header("location:index.html");
		//echo "<script> alert('Successfully Register') </script>";
		$message[] = 'Register succesfully';
		header('location:index.html');
        
	} 
	else
	{
		$message[] = 'Please Try Again!';
		header('location:index.html');
		//echo"<script> alert('Please Enter Some Valid Information')</script>";
	}

}

?>

