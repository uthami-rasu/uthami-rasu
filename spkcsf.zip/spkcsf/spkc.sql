-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2024 at 02:56 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spkc`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_details`
--

CREATE TABLE `academic_details` (
  `rollno` int(10) NOT NULL,
  `regno` bigint(20) NOT NULL,
  `academic_year` varchar(9) NOT NULL,
  `adm_num` bigint(50) NOT NULL,
  `adm_date` date NOT NULL,
  `course_type` varchar(30) NOT NULL,
  `course_name` varchar(30) NOT NULL,
  `year` varchar(30) NOT NULL,
  `tc_no` bigint(50) NOT NULL,
  `tc_application_date` date NOT NULL,
  `tc_issue_date` date NOT NULL,
  `remarks` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_details`
--

INSERT INTO `academic_details` (`rollno`, `regno`, `academic_year`, `adm_num`, `adm_date`, `course_type`, `course_name`, `year`, `tc_no`, `tc_application_date`, `tc_issue_date`, `remarks`) VALUES
(21639, 20211231401233, '2021-2022', 3, '2021-04-01', 'ug', 'Bca', 'year_1', 769854238799, '2021-04-01', '0000-00-00', ''),
(21649, 20211231401248, '2021-2022', 4, '2021-04-01', 'ug', 'Bca', 'year_1', 769854238799, '2021-09-01', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `parent_details`
--

CREATE TABLE `parent_details` (
  `rollno` int(11) NOT NULL,
  `relation` varchar(15) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `gname` varchar(30) NOT NULL,
  `f_occupation` varchar(30) NOT NULL,
  `m_occupation` varchar(30) NOT NULL,
  `goccupation` varchar(30) NOT NULL,
  `gann_income` bigint(20) NOT NULL,
  `ann_income` bigint(20) NOT NULL,
  `parent_contact` bigint(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `district` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `pin_code` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_details`
--

INSERT INTO `parent_details` (`rollno`, `relation`, `fname`, `mname`, `gname`, `f_occupation`, `m_occupation`, `goccupation`, `gann_income`, `ann_income`, `parent_contact`, `address`, `city`, `district`, `state`, `pin_code`) VALUES
(21639, 'father', 'poovalingam', 'kalyani', '', 'dailywages', 'Homemaker', '', 0, 80000, 9600989147, '2/198A,North Street', 'Ayansingampatti', 'tirunelveli', 'tamilnadu', 627416),
(21649, 'father', 'raja', 'rani', '', 'dailywages', 'Homemaker', '', 0, 20000, 9600989147, '3a,south street', 'vellanguli', 'tirunelveli', 'tamilnadu', 627416);

-- --------------------------------------------------------

--
-- Table structure for table `personal`
--

CREATE TABLE `personal` (
  `rollno` int(11) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `s_dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `wtsapp` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `schltype` varchar(30) NOT NULL,
  `schlstu` varchar(100) NOT NULL,
  `emis` bigint(20) NOT NULL,
  `religion` varchar(30) NOT NULL,
  `community` varchar(30) NOT NULL,
  `caste` varchar(30) NOT NULL,
  `nation` varchar(30) NOT NULL,
  `mother_tongue` varchar(30) NOT NULL,
  `aadharno` bigint(20) NOT NULL,
  `first_graduation` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal`
--

INSERT INTO `personal` (`rollno`, `sname`, `s_dob`, `gender`, `phno`, `wtsapp`, `email`, `schltype`, `schlstu`, `emis`, `religion`, `community`, `caste`, `nation`, `mother_tongue`, `aadharno`, `first_graduation`) VALUES
(21639, 'ramasubramanian p', '2003-10-17', '', 9600989147, 9600989147, 'poovalingamramasubramanian@gmail.com', 'none', 'st.marys', 8765334678876767, '', '', '', '', '', 987654321, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_details`
--
ALTER TABLE `academic_details`
  ADD PRIMARY KEY (`rollno`),
  ADD UNIQUE KEY `adm_num` (`adm_num`);

--
-- Indexes for table `parent_details`
--
ALTER TABLE `parent_details`
  ADD PRIMARY KEY (`rollno`);

--
-- Indexes for table `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`rollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_details`
--
ALTER TABLE `academic_details`
  MODIFY `adm_num` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
